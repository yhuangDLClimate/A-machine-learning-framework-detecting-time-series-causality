function coeff=Reservoir_predict(inputSequence,outputSequence)
%% Please note: 
% The original version of the reservoir computing code is from the MINDS group at 
% the Unversity of Groningen��https://www.ai.rug.nl/minds/research/esnresearch/).
% In this website,the code about Echo state newtork and reservoir computing is open access. 
% 
% Before using this code, you should  add a matlab path for the
% "ESNToolbox" in your computer. 
% 
% We thank the MINDS group very much for their support. 
%
%---Yu Huang 2020/7/21
%Reference: Huang Y,Fu Z,and Franzke CL.Detecting causality from time series in a machine learning framework.Chaos,30:6,2020.

%%%% split the data into train and test

train_fraction = 0.4; % use 40% in training and 60% in testing
[trainInputSequence, testInputSequence] = ...
    split_train_test(inputSequence,train_fraction);
[trainOutputSequence,testOutputSequence] = ...
    split_train_test(outputSequence,train_fraction);



%%%% generate an esn 
nInputUnits = 1; 
nInternalUnits = 400;%reservoir size(the number of neurons) 
nOutputUnits = 1; 


% Note: Different settings for different parameters can alter the prediction
% skill curve, but the maximum and maximum position will be not changed. 
esn = generate_esn(nInputUnits, nInternalUnits, nOutputUnits, ...
    'spectralRadius',1.8,'inputScaling',10,'inputShift',1, ...
    'teacherScaling',0.1,'teacherShift',0,'feedbackScaling', 0, ...
    'type', 'plain_esn'); 
%%% VARIANTS YOU MAY WISH TO TRY OUT
% (Comment out the above "esn = ...", comment in one of the variants
% below)

% % Use a leaky integrator ESN
% esn = generate_esn(nInputUnits, nInternalUnits, nOutputUnits, ...
%     'spectralRadius',0.5,'inputScaling',[0.1;0.1],'inputShift',[0;0], ...
%     'teacherScaling',[0.3],'teacherShift',[-0.2],'feedbackScaling', 0, ...
%     'type', 'leaky_esn'); 
% 
% % Use a time-warping invariant ESN (makes little sense here, just for
% % demo's sake)
% esn = generate_esn(nInputUnits, nInternalUnits, nOutputUnits, ...
%     'spectralRadius',0.5,'inputScaling',[0.1;0.1],'inputShift',[0;0], ...
%     'teacherScaling',[0.3],'teacherShift',[-0.2],'feedbackScaling', 0, ...
%     'type', 'twi_esn'); 

% % Do online RLS learning instead of batch learning.
% esn = generate_esn(nInputUnits, nInternalUnits, nOutputUnits, ...
%       'spectralRadius',0.4,'inputScaling',[0.1;0.5],'inputShift',[0;1], ...
%       'teacherScaling',[0.3],'teacherShift',[-0.2],'feedbackScaling',0, ...
%       'learningMode', 'online' , 'RLS_lambda',0.9999995 , 'RLS_delta',0.000001, ...
%       'noiseLevel' , 0.00000000) ; 

esn.internalWeights = esn.spectralRadius * esn.internalWeights_UnitSR;

%%%% train the ESN
nForgetPoints = 50 ; % discard the first 100 points
[trainedEsn stateMatrix] = ...
    train_esn(trainInputSequence, trainOutputSequence, esn, nForgetPoints) ; 

%%%% save the trained ESN
% save_esn(trainedEsn, 'esn_narma_demo_1'); 

%%%% plot the internal states of 4 units
% figure(1)
% nPoints = 200 ; 
% plot_states(stateMatrix,[1 2 3 4], nPoints, 1, 'traces of first 4 reservoir units') ; 

% compute the output of the trained ESN on the training and testing data,
% discarding the first nForgetPoints of each
nForgetPoints = 50 ; 
predictedTrainOutput = test_esn(trainInputSequence, trainedEsn, nForgetPoints);
predictedTestOutput = test_esn(testInputSequence,  trainedEsn, nForgetPoints) ; 

% create input-output plots
% nPlotPoints = 100 ; 
% plot_sequence(trainOutputSequence(nForgetPoints+1:end,:), predictedTrainOutput, nPlotPoints,...
%     'training: teacher sequence (red) vs predicted sequence (blue)');
% plot_sequence(testOutputSequence(nForgetPoints+1:end,:), predictedTestOutput, nPlotPoints, ...
%     'testing: teacher sequence (red) vs predicted sequence (blue)') ; 

%%%%compute NRMSE training error
% trainError = compute_NRMSE(predictedTrainOutput, trainOutputSequence); 
% disp(sprintf('train NRMSE = %s', num2str(trainError)))

%%%%compute NRMSE testing error
% testError = compute_NRMSE(predictedTestOutput, testOutputSequence); 
% disp(sprintf('test NRMSE = %s', num2str(testError)))

R1=[trainOutputSequence(nForgetPoints+1:end,:),predictedTrainOutput];
R2=[testOutputSequence(nForgetPoints+1:end,:), predictedTestOutput];
Result=[R1;R2];

coeff=corr(Result(:,1),Result(:,2));



