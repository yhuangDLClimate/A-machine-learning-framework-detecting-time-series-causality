%% --generating the data of an example system (x-y logistic model)
%Please note:  this code is a demotration for the paper: 
% Huang Y,Fu Z,and Franzke CL.Detecting causality from time series in a machine learning framework.Chaos,30:6,2020.

clc;clear;close
x(1)=0.1;y(1)=0.2;
for i=2:12
    x(i)=x(i-1)*(3.78-3.78*x(i-1));
    y(i)=y(i-1)*(3.77-3.77*y(i-1));
end

for i=12:20000
    x(i)=x(i-1)*(3.78-3.78*x(i-1));
    y(i)=y(i-1)*(3.77-3.77*y(i-1)-0.8*x(i-1-10));
end


xy=[x(15001:end)',y(15001:end)'];
save xy xy;


%% --testing the method
clc;clear;close;
load('xy');

lag=-30:30;% the lag for prediction


for i=1:61
    X=xy(31-lag(i):end-31-lag(i),1);
    Y=xy(31:end-31,2);
    xxmapy(i,:)= Reservoir_predict(X,Y);% uisng X(t) to predict Y(t+tau) 
    
   
    Y=xy(31-lag(i):end-31-lag(i),2);
    X=xy(31:end-31,1);
    yxmapx(i,:)= Reservoir_predict(Y,X);% uisng X(t) to predict Y(t+tau)     
end

figure
plot(lag,xxmapy,lag,yxmapx,'linewidth',2);grid on;
title('RC prediction skill for a delay-coupled logistic system');legend(['x predicts y_l_a_g'],['y predicts x_l_a_g']);
xlabel('Prediction lag');ylabel('Prediction skill');




